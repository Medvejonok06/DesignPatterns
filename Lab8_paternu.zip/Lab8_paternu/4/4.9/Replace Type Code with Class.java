//Створив клас ProductType для представлення типу продукту замість використання числового коду 

public class ProductType {
    private String name;

    public ProductType(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

//Перевизначення методу equals для правильного порівняння об'єктів ProductType
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true; //Якщо об’єкти посилаються на ту саму адресу — вони рівні
        if (!(obj instanceof ProductType)) return false; //Якщо об'єкт не є ProductType — не рівні
        ProductType other = (ProductType) obj; //Приводимо об'єкт до типу ProductType
        return name != null ? name.equals(other.name) : other.name == null; //Порівнюємо значення поля name
    }

    //Перевизначення методу hashCode для правильного хешування об'єктів
    @Override
    public int hashCode() {
        return name != null ? name.hashCode() : 0;
    }

    //Перевизначення методу toString для зручного виводу інформації про об'єкт
    @Override
    public String toString() {
        return "ProductType{name='" + name + "'}";
    }
}

public class Product {
    private ProductType type;
    private String name;

    public Product(ProductType type, String name) {
        this.type = type;
        this.name = name;
    }

    public ProductType getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    // Інші методи класу...
}