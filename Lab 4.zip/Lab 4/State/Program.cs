﻿using System;

// Інтерфейс стану
interface IState
{
    void Handle(Context context);
}

// Конкретний стан A
class StateA : IState
{
    public void Handle(Context context)
    {
        Console.WriteLine("Перехід у стан B");
        context.SetState(new StateB());
    }
}

// Конкретний стан B
class StateB : IState
{
    public void Handle(Context context)
    {
        Console.WriteLine("Перехід у стан A");
        context.SetState(new StateA());
    }
}

// Контекст, що управляє станами
class Context
{
    private IState _state;

    public Context(IState state) => _state = state;

    public void SetState(IState state) => _state = state;

    public void Request() => _state.Handle(this);
}

// Тестування
class Program
{
    static void Main()
    {
        Context context = new Context(new StateA());

        context.Request(); // Перехід до стану B
        context.Request(); // Перехід до стану A
    }
}
