//Замість трьох масивів (carNames, carPrices, carYears) створив клас Car з відповідними полями

import java.util.ArrayList;
import java.util.List;

class Car {
    private String name;
    private int price;
    private int year;

    public Car(String name, int price, int year) {
        this.name = name;
        this.price = price;
        this.year = year;
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public int getYear() {
        return year;
    }
}

class CarData {
    private List<Car> cars;

    public CarData(List<Car> cars) {
        this.cars = cars;
    }

    public void printCars() {
        System.out.println("Cars stored as objects:");
        for (Car car : cars) {
            System.out.println(car.getName() + " - Price: " + car.getPrice() + ", Year: " + car.getYear());
        }
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        //Створення списку об'єктів Car
        List<Car> carList = new ArrayList<>();
        carList.add(new Car("Toyota", 20000, 2015));
        carList.add(new Car("Honda", 22000, 2018));
        carList.add(new Car("BMW", 45000, 2020));

        //Ініціалізація CarData з об'єктами Car
        CarData carData = new CarData(carList);
        carData.printCars();
    }
}
