public class Account {
    private double balance;
    private double interestRate;

    public double getBalance() {
        return balance;
    }

    public double getInterestRate() {
        return interestRate;
    }

public class Bank {
    private List<Account> accounts;

    public void processAccounts() {
        for (Account account : accounts) {
            calculateInterest(account);
        }
    }

    //Нове місце для методу
    public void calculateInterest(Account account) {
        double interest = account.getBalance() * account.getInterestRate() / 100;
        System.out.println("Interest calculated: " + interest);
        }
    }
}