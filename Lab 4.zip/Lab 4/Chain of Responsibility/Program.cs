﻿using System;

// Абстрактний клас обробника
abstract class Handler
{
    protected Handler NextHandler; // Наступний обробник у ланцюжку

    // Метод для встановлення наступного обробника
    public void SetNext(Handler handler) => NextHandler = handler;

    // Абстрактний метод обробки запиту
    public abstract void HandleRequest(int request);
}

// Конкретний обробник 1
class ConcreteHandler1 : Handler
{
    public override void HandleRequest(int request)
    {
        if (request < 10) // Якщо значення менше 10, обробляємо тут
            Console.WriteLine($"ConcreteHandler1 обробив запит {request}");
        else
            NextHandler?.HandleRequest(request); // Передаємо далі, якщо є наступний обробник
    }
}

// Конкретний обробник 2
class ConcreteHandler2 : Handler
{
    public override void HandleRequest(int request)
    {
        if (request >= 10 && request < 20) // Якщо значення між 10 і 20, обробляємо тут
            Console.WriteLine($"ConcreteHandler2 обробив запит {request}");
        else
            NextHandler?.HandleRequest(request); // Передаємо далі
    }
}

// Тестування
class Program
{
    static void Main()
    {
        Handler h1 = new ConcreteHandler1(); // Створюємо перший обробник
        Handler h2 = new ConcreteHandler2(); // Створюємо другий обробник

        h1.SetNext(h2); // Зв'язуємо обробники в ланцюг

        h1.HandleRequest(5);  // Обробить ConcreteHandler1
        h1.HandleRequest(15); // Обробить ConcreteHandler2
    }
}
