//Додав методи для контролю додавання та видалення елементів колекції

import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

public class Library {
    private List<Book> books;

    public Library(List<Book> books) {
        //Створюємо копію списку
        this.books = new ArrayList<>(books);
    }

    //Повертаємо незмінний список книг
    public List<Book> getBooks() {
        return Collections.unmodifiableList(books);
    }

    //Прибрав сеттер, щоб не дозволяти повністю замінювати список

    public void addBook(Book book) {
        books.add(book);
    }

    public void removeBook(Book book) {
        books.remove(book);
    }
}
