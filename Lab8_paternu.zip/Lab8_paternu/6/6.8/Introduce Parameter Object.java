//Створив окремий об'єкт, який буде інкапсулювати ці параметри

// Клас користувача, який інкапсулює параметри
public class User {
    private String name;
    private int age;
    private String email;

    public User(String name, int age, String email) {
        this.name = name;
        this.age = age;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }
}

public class UserManager {

    //Метод приймає один об'єкт User
    public void processUser(User user) {
        System.out.println("Processing user: " + user.getName() +
                           ", Age: " + user.getAge() +
                           ", Email: " + user.getEmail());
    }
}
