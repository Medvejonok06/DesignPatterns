//Створив окремий клас OrderProcessorHelper, в якому змінні стали полями класу

public class OrderProcessor {
    public void processOrder(Order order) {
        new OrderProcessorHelper(order).process();
    }
}

class OrderProcessorHelper {
    private Order order;
    private double totalCost;

    public OrderProcessorHelper(Order order) {
        this.order = order;
        this.totalCost = 0;
    }

    public void process() {
        calculateTotalCost();
        applyDiscountIfVip();
        finalizeOrder();
    }

    private void calculateTotalCost() {
        int itemCount = order.getItemCount();
        for (int i = 0; i < itemCount; i++) {
            Item item = order.getItem(i);
            double itemPrice = item.getPrice();
            int quantity = item.getQuantity();
            totalCost += itemPrice * quantity;
        }
    }

    private void applyDiscountIfVip() {
        Customer customer = order.getCustomer();
        if (customer.isVIP()) {
            totalCost -= totalCost * 0.1; //10% знижка
        }
    }

    private void finalizeOrder() {
        order.setTotalCost(totalCost);
        order.setStatus("Processed");
    }
}
