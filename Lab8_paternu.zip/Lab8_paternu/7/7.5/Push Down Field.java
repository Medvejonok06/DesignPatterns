//Перемістив це поле з суперкласу в відповідні підкласи

class Vehicle {
  protected String model;
  //Поля brand і loadCapacity видалив звідси, бо вони не потрібні всім підкласам
}

class Car extends Vehicle {
  protected String brand;
}

class Truck extends Vehicle {
  protected int loadCapacity;
}
