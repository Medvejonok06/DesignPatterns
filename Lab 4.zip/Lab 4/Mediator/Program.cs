﻿using System;

// Клас-посередник, який координує взаємодію між об'єктами
class Mediator
{
    public void SendMessage(string message, Colleague colleague)
    {
        Console.WriteLine($"{colleague.Name} отримав повідомлення: {message}");
    }
}

// Клас-учасник, який взаємодіє через посередника
class Colleague
{
    public string Name { get; } // Ім'я учасника
    private Mediator _mediator; // Посередник

    public Colleague(string name, Mediator mediator)
    {
        Name = name;
        _mediator = mediator;
    }

    public void Send(string message) => _mediator.SendMessage(message, this); // Надсилання повідомлення через посередника
}

// Тестування патерну
class Program
{
    static void Main()
    {
        Mediator mediator = new Mediator();
        Colleague user1 = new Colleague("User1", mediator);
        Colleague user2 = new Colleague("User2", mediator);

        user1.Send("Привіт!"); // User1 надсилає повідомлення
        user2.Send("Привіт, User1!"); // User2 відповідає
    }
}
