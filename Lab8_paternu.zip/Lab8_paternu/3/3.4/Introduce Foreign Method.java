//Додав метод isWeekend() у клієнтський клас Client, і передав Calendar як аргумент

import java.util.Calendar;

public class Client {

  public void doSomething() {
    Calendar currentDate = Calendar.getInstance();
    if (isWeekend(currentDate)) {
      System.out.println("It's weekend!");
    } else {
      System.out.println("It's not weekend!");
    }
  }

  //Метод, що виконує перевірку дня тижня (субота чи неділя)
  public boolean isWeekend(Calendar date) {
    int dayOfWeek = date.get(Calendar.DAY_OF_WEEK);
    return dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY;
  }
}
