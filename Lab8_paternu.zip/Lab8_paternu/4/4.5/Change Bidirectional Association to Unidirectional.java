//Видалив невживаний зв’язок: у класі Employee прибирав поле department та пов’язаний з ним код, залишив посилання тільки у класі Department на список працівників

import java.util.List;

public class Department {
    private String name;
    private List<Employee> employees;

    public Department(String name, List<Employee> employees) {
        this.name = name;
        this.employees = employees;
    }

    public String getName() {
        return name;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    // Додаткові методи...
}

public class Employee {
    private String name;
    // Прибрано поле department, бо Employee більше не тримає посилання на Department

    public Employee(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    // Додаткові методи...
}
