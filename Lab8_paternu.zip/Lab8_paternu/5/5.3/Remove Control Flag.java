//Замість використання прапорця — використав return для негайного завершення методу при досягненні умови

public class Searcher {

    public void searchElement(int[] array, int target) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == target) {
                System.out.println("Element found");
                return;
            }
        }
        System.out.println("Element not found");
    }
}
