//Замість поля status з кодуванням типу — використав об'єкт-стан, який визначає поведінку замовлення

public interface OrderStatus {
    void handleStatus(Order order);
    String getStatusName();
}

public class Order {
    private OrderStatus status;

    public Order() {
        //Початковий стан - Нове замовлення
        this.status = new NewStatus();
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public OrderStatus getStatus() {
        return status;
    }

    //Виклик поведінки відповідно до поточного стану
    public void processStatus() {
        status.handleStatus(this);
    }
}

//Конкретний стан "Нове замовлення"
public class NewStatus implements OrderStatus {
    @Override
    public void handleStatus(Order order) {
        System.out.println("Order is new. Ready for processing.");
        order.setStatus(new ProcessingStatus());
    }
    
    @Override
    public String getStatusName() {
        return "New";
    }
}

//Конкретний стан "В обробці"
public class ProcessingStatus implements OrderStatus {
    @Override
    public void handleStatus(Order order) {
        System.out.println("Order is being processed.");
        //Можливий перехід в інший стан:
        order.setStatus(new CompletedStatus());
    }
    
    @Override
    public String getStatusName() {
        return "Processing";
    }
}

//Конкретний стан "Виконано"
public class CompletedStatus implements OrderStatus {
    @Override
    public void handleStatus(Order order) {
        System.out.println("Order has been completed.");
        //Можливе завершення або інші дії
    }
    
    @Override
    public String getStatusName() {
        return "Completed";
    }
}

//Конкретний стан "Скасовано"
public class CancelledStatus implements OrderStatus {
    @Override
    public void handleStatus(Order order) {
        System.out.println("Order has been cancelled.");
        //Можливі додаткові дії при скасуванні
    }
    
    @Override
    public String getStatusName() {
        return "Cancelled";
    }
}
