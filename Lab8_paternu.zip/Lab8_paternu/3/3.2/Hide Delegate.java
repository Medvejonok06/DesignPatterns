//Додав метод getManagerName() у клас Employee для приховування доступу до Department, щоб клієнтський код не звертався до getDepartment().getManager().getName()

public class Department {
    private String name;
    private Employee manager;

    public Employee getManager() {
        return manager;
    }
}

public class Employee {
    private String name;
    private Department department;

    public Department getDepartment() {
        return department;
    }

    public String getName() {
        return name;
    }

    //Додав метод для приховування делегованого виклику
    public String getManagerName() {
        return department.getManager().getName();
    }
}
