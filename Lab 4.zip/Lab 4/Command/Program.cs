﻿using System;

// Інтерфейс команди
interface ICommand
{
    void Execute(); // Метод виконання команди
}

// Клас, який отримує команди
class Light
{
    public void TurnOn() => Console.WriteLine("Світло увімкнено");
    public void TurnOff() => Console.WriteLine("Світло вимкнено");
}

// Команда для увімкнення світла
class TurnOnCommand : ICommand
{
    private Light _light; // Приймач команди

    public TurnOnCommand(Light light) => _light = light; // Передаємо об'єкт світла

    public void Execute() => _light.TurnOn(); // Виконання команди
}

// Команда для вимкнення світла
class TurnOffCommand : ICommand
{
    private Light _light;

    public TurnOffCommand(Light light) => _light = light;

    public void Execute() => _light.TurnOff();
}

// Пульт керування (використовує команди)
class RemoteControl
{
    private ICommand _command; // Поточна команда

    public void SetCommand(ICommand command) => _command = command; // Встановлюємо команду

    public void PressButton() => _command.Execute(); // Виконуємо команду
}

// Тестування
class Program
{
    static void Main()
    {
        Light light = new Light(); // Створюємо приймач команд (світло)
        RemoteControl remote = new RemoteControl(); // Створюємо пульт

        remote.SetCommand(new TurnOnCommand(light)); // Встановлюємо команду "увімкнути"
        remote.PressButton(); // Виконуємо команду

        remote.SetCommand(new TurnOffCommand(light)); // Встановлюємо команду "вимкнути"
        remote.PressButton(); // Виконуємо команду
    }
}
