//Створив ієрархію класів, де поведінка визначається у підкласах, замість використання умовних операторів

public abstract class Product {
    protected String name;

    public Product(String name) {
        this.name = name;
    }

    //Абстрактний метод, поведінка якого залежить від типу продукту
    public abstract void process();

    public String getName() {
        return name;
    }
}

//Підклас для типу 1 продукту
public class ProductType1 extends Product {
    public ProductType1(String name) {
        super(name);
    }

    @Override
    public void process() {
        //Поведінка для типу 1
        System.out.println("Processing product type 1: " + name);
    }
}

//Підклас для типу 2 продукту
public class ProductType2 extends Product {
    public ProductType2(String name) {
        super(name);
    }

    @Override
    public void process() {
        //Поведінка для типу 2
        System.out.println("Processing product type 2: " + name);
    }
}

//Підклас для продуктів за замовчуванням або інших типів
public class DefaultProduct extends Product {
    public DefaultProduct(String name) {
        super(name);
    }

    @Override
    public void process() {
        //Поведінка за замовчуванням
        System.out.println("Processing default product: " + name);
    }
}
