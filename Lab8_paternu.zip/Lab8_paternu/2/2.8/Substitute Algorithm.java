//Використав StringBuilder для підвищення ефективності

public class StringManipulator {

    //Метод для обробки рядка: змінює регістр кожного символу
    public String manipulateString(String input) {
        //Створення об'єкта StringBuilder
        StringBuilder result = new StringBuilder();  //ефективна альтернатива конкатенації

        //Проходимо по кожному символу вхідного рядка
        for (int i = 0; i < input.length(); i++) {
            //Отримуємо символ за поточним індексом
            char ch = input.charAt(i);

            if (Character.isLowerCase(ch)) {
                result.append(Character.toUpperCase(ch));
            }
            else if (Character.isUpperCase(ch)) {
                result.append(Character.toLowerCase(ch));
            }
            else {
                result.append(ch);
            }
        }

        return result.toString();
    }

    // Інші методи...
}