﻿//Дає змогу додавати до програми нові операції, не змінюючи класи об’єктів, над якими ці операції можуть виконуватися
using System;
using System.Collections.Generic;

//Інтерфейс елемента, який можна "відвідати"
interface IElement
{
    void Accept(IVisitor visitor); //Метод для прийняття відвідувача
}

class ConcreteElementA : IElement
{
    public void Accept(IVisitor visitor) => visitor.Visit(this); //Викликає метод Visit у відвідувача
    public string SpecificMethodA() => "Метод A"; //Унікальний метод класу A
}

class ConcreteElementB : IElement
{
    public void Accept(IVisitor visitor) => visitor.Visit(this);
    public string SpecificMethodB() => "Метод B"; //Унікальний метод класу B
}

interface IVisitor
{
    void Visit(ConcreteElementA element); 
    void Visit(ConcreteElementB element);
}

//Конкретний відвідувач, який виконує операцію над елементами
class ConcreteVisitor : IVisitor
{
    public void Visit(ConcreteElementA element)
    {
        Console.WriteLine($"Відвідувач обробляє {element.SpecificMethodA()}");
    }

    public void Visit(ConcreteElementB element)
    {
        Console.WriteLine($"Відвідувач обробляє {element.SpecificMethodB()}");
    }
}

class Program
{
    static void Main()
    {
        List<IElement> elements = new List<IElement>
        {
            new ConcreteElementA(),
            new ConcreteElementB()
        };

        IVisitor visitor = new ConcreteVisitor(); //Створюємо відвідувача

        foreach (var element in elements) 
        {
            element.Accept(visitor); //Передаємо кожен елемент відвідувачу
        }
    }
}
