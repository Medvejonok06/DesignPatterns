//Зробив методи ідентичними, а потім перемістив їх у суперклас

class Animal {
    //Метод, що був дубльований у підкласах, тепер винесений у суперклас
    public void makeSound() {
        System.out.println("Some generic animal sound");
    }
}

class Dog extends Animal {
    //Метод makeSound() успадкований з Animal
    @Override
    public void makeSound() {
        System.out.println("Woof woof!");
    }
}

class Cat extends Animal {
    //Метод makeSound() успадкований з Animal
    @Override
    public void makeSound() {
        System.out.println("Meow meow!");
    }
}
