//Виділення класу для товарів (Item), розрахунку ціни (OrderCalculator), розбиття методу processOrder на менші методи, які відповідають за окремі кроки обробки
// Клас Item - описує товар
public class Item {
    private String name;
    private double price;

    public Item(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }
}

//Клас для розрахунку вартості замовлення
public class OrderCalculator {
    public double calculateTotalPrice(List<Item> items) {
        double price = 0.0;
        for (Item item : items) {
            price += item.getPrice();
        }
        return price;
    }
}

//Клас Order
public class Order {
    private String customerName;
    private List<Item> items;
    private double totalPrice;
    private OrderCalculator calculator;

    public Order(String customerName, List<Item> items, OrderCalculator calculator) {
        this.customerName = customerName;
        this.items = items;
        this.calculator = calculator;
        this.totalPrice = calculator.calculateTotalPrice(items);
    }

    public void processOrder() {
        validateOrder();
        chargePayment();
        sendConfirmation();
        //інші кроки обробки замовлення, кожен у власному методі
    }

    private void validateOrder() {
        //Логіка перевірки замовлення
    }

    private void chargePayment() {
        //Логіка оплати
    }

    private void sendConfirmation() {
        //Логіка підтвердження замовлення
    }

    public double getTotalPrice() {
        return totalPrice;
    }
}
