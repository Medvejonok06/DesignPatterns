﻿using System;

// Абстрактний клас із шаблонним методом
abstract class TemplateClass
{
    public void TemplateMethod()
    {
        Step1();
        Step2();
        Step3();
    }

    protected abstract void Step1();
    protected abstract void Step2();
    protected virtual void Step3() => Console.WriteLine("Крок 3: Спільна реалізація");
}

// Реалізація для варіанту A
class ConcreteClassA : TemplateClass
{
    protected override void Step1() => Console.WriteLine("Крок 1: Реалізація A");
    protected override void Step2() => Console.WriteLine("Крок 2: Реалізація A");
}

// Реалізація для варіанту B
class ConcreteClassB : TemplateClass
{
    protected override void Step1() => Console.WriteLine("Крок 1: Реалізація B");
    protected override void Step2() => Console.WriteLine("Крок 2: Реалізація B");
}

// Тестування
class Program
{
    static void Main()
    {
        TemplateClass a = new ConcreteClassA();
        TemplateClass b = new ConcreteClassB();

        Console.WriteLine("Виконання алгоритму для A:");
        a.TemplateMethod();

        Console.WriteLine("\nВиконання алгоритму для B:");
        b.TemplateMethod();
    }
}
