//Замінив "число" 100 на константу з пояснювальним ім'ям

import java.util.ArrayList;
import java.util.List;

public class Example {
    private static final int MAX_ITEMS = 100; //Максимальна кількість елементів

    public static void main(String[] args) {
        List<String> items = new ArrayList<>();
        //Додавання елементів у список
        for (int i = 0; i < MAX_ITEMS; i++) {
            items.add("Item " + i);
        }
    }
}
