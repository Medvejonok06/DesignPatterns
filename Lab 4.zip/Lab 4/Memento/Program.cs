﻿using System;
using System.Collections.Generic;

// Клас, що зберігає стан об'єкта
class Memento
{
    public string State { get; private set; } // Збережений стан

    public Memento(string state) => State = state; // Конструктор для встановлення стану
}

// Клас, стан якого зберігається
class Originator
{
    public string State { get; set; } // Поточний стан

    public Memento SaveState() => new Memento(State); // Збереження стану

    public void RestoreState(Memento memento) => State = memento.State; // Відновлення стану
}

// Клас, що управляє збереженням та відновленням стану
class Caretaker
{
    private Stack<Memento> _history = new Stack<Memento>(); // Історія станів

    public void Save(Originator originator) => _history.Push(originator.SaveState()); // Збереження стану

    public void Undo(Originator originator)
    {
        if (_history.Count > 0)
            originator.RestoreState(_history.Pop()); // Відновлення останнього збереженого стану
    }
}

// Тестування
class Program
{
    static void Main()
    {
        Originator originator = new Originator();
        Caretaker caretaker = new Caretaker();

        originator.State = "Стан 1";
        caretaker.Save(originator); // Зберігаємо стан

        originator.State = "Стан 2";
        caretaker.Save(originator);

        originator.State = "Стан 3";
        Console.WriteLine($"Поточний стан: {originator.State}");

        caretaker.Undo(originator); // Відкат
        Console.WriteLine($"Відновлений стан: {originator.State}");

        caretaker.Undo(originator);
        Console.WriteLine($"Відновлений стан: {originator.State}");
    }
}
