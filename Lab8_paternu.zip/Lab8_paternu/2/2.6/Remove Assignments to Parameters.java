//Створив локальну змінну `newUser`, якій присвоєно параметр `user`, і далі використовуються лише локальні змінні

public class UserManager {
    private List<User> users;

    public void addUser(User user) {
        if (user != null) {
            User newUser = user; //Створюємо локальну копію посилання
            newUser.setRegistered(true);
            users.add(newUser);
        }
    }

    // Інші методи класу...
}
