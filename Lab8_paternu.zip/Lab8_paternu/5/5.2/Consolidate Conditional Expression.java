//Об'єднав ці умови в один умовний оператор за допомогою логічного "або".

public class PaymentProcessor {

    public void processPayment(double amount, boolean isMember, boolean isDiscountAvailable) {
        if ((amount > 100 && isMember) || (amount > 200 && isDiscountAvailable)) {
            applyDiscount();
        }
    }

    private void applyDiscount() {
        System.out.println("Discount applied.");
    }
}
