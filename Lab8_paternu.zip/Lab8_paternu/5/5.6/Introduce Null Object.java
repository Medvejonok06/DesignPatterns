//Створив Null-об’єкт (NullAddress), який реалізує поведінку за замовчуванням

// Базовий клас Address
public class Address {
    private String street;
    private String city;

    public Address(String street, String city) {
        this.street = street;
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public String getCity() {
        return city;
    }

    public boolean isNull() {
        return false;
    }

    public void printAddress() {
        System.out.println(street + ", " + city);
    }
}

//Null Object: NullAddress
class NullAddress extends Address {
    public NullAddress() {
        super("N/A", "N/A");
    }

    @Override
    public boolean isNull() {
        return true;
    }

    @Override
    public void printAddress() {
        System.out.println("Address not available");
    }
}

//Клас Customer
class Customer {
    private Address address;

    public Customer(Address address) {
        //Якщо передано null — замінюємо на NullAddress
        if (address == null) {
            this.address = new NullAddress();
        } else {
            this.address = address;
        }
    }

    public Address getAddress() {
        return address;
    }

    public void printCustomerAddress() {
        address.printAddress(); //без перевірки на null
    }
}

//Тестування
public class Main {
    public static void main(String[] args) {
        Customer customerWithAddress = new Customer(new Address("Main St", "Kyiv"));
        Customer customerWithoutAddress = new Customer(null);

        customerWithAddress.printCustomerAddress();       //Виведе: Main St, Kyiv
        customerWithoutAddress.printCustomerAddress();    //Виведе: Address not available
    }
}
