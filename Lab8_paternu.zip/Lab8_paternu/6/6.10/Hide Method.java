//Зробив метод приватним і захищеним

public class Calculator {

    public int calculate(int a, int b) {
        int result = multiply(a, b);
        return result + add(a, b);
    }

    private int multiply(int x, int y) {
        return x * y;
    }

    protected int add(int x, int y) {
        return x + y;
    }
}
