//Виділив кожну дію у свій окремий метод

public class Printer {

    public void printTextDocument(String content) {
        System.out.println("Printing text document: " + content);
    }

    public void printImageDocument(String content) {
        System.out.println("Printing image document: " + content);
    }

    public void printUnknownDocument(String type) {
        System.out.println("Unknown document type: " + type);
    }
}
