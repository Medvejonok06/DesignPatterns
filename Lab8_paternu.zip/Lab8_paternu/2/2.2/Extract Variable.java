//Для зменшення дублювання логіки, Math.PI * radius * radius (площа круга) були винесені в окремі змінні: area → для площі, ircumference → для довжини кола

public class Circle {
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    public double calculateArea() {
        double area = Math.PI * radius * radius;
        return area;
    }

    public double calculateCircumference() {
        double circumference = 2 * Math.PI * radius;
        return circumference;
    }

    public void printCircleDetails() {
        double area = Math.PI * radius * radius;
        double circumference = 2 * Math.PI * radius;

        System.out.println("Circle with radius " + radius);
        System.out.println("Area: " + area);
        System.out.println("Circumference: " + circumference);
    }

    // Інші методи класу...
}
