//Додав явну перевірку перед діленням, використовуючи assert

public class Statistics {

    public double calculateAverage(int[] numbers) {
        //Перевірка припущення: масив не повинен бути порожнім
        assert numbers != null && numbers.length > 0 : "Масив не повинен бути порожнім";

        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        return (double) sum / numbers.length;
    }

    public static void main(String[] args) {
        Statistics stats = new Statistics();

        int[] validArray = {10, 20, 30};
        System.out.println("Average: " + stats.calculateAverage(validArray)); //Виведе: 20.0

        int[] emptyArray = {};
        //В наступному виклику виникне AssertionError, якщо увімкнено assert
        System.out.println("Average: " + stats.calculateAverage(emptyArray));
    }
}
