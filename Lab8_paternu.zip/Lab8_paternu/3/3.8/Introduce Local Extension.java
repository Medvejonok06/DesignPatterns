//Створив новий клас DateHelperExtended, який: або успадковує DateHelper (extends), або огортає його (ми вибрали перший варіант — наслідування), і додає новий метод daysBetween(Date startDate, Date endDate)

import java.util.Date;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

//Оригінальний службовий клас
class DateHelper {
  public static Date addDays(Date date, int days) {
    //Отримуємо час дати в мілісекундах
    long millis = date.getTime();
    
    //Додаємо до нього кількість мілісекунд, що відповідає переданим дням
    millis += TimeUnit.DAYS.toMillis(days);
        return new Date(millis);
  }
}

//Розширення класу DateHelper
class DateHelperExtended extends DateHelper {
  public static long daysBetween(Date startDate, Date endDate) {
    //Різниця між кінцевою та початковою датами в мілісекундах
    long diffInMillies = endDate.getTime() - startDate.getTime();
    
    //Перетворюємо мілісекунди в дні
    return TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
  }
}

//Клас-клієнт, який демонструє використання створеного розширення
public class Client {
  public static void main(String[] args) {
    //Створюємо об’єкти Calendar і встановлюємо їм дати
    Calendar cal1 = Calendar.getInstance();
    cal1.set(2025, Calendar.JANUARY, 1);

    Calendar cal2 = Calendar.getInstance();
    cal2.set(2025, Calendar.JANUARY, 18);

    Date date1 = cal1.getTime();
    Date date2 = cal2.getTime();

    //Викликаємо метод daysBetween для обчислення різниці між датами
    long daysDiff = DateHelperExtended.daysBetween(date1, date2);
    
    System.out.println("Days between: " + daysDiff);
  }
}