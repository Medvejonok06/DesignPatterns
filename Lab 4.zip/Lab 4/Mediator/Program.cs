﻿//Дає змогу зменшити зв’язаність великої кількості класів між собою, завдяки переміщенню цих зв’язків до одного класу-посередника
using System;

//Клас-посередник, який координує взаємодію між об'єктами
class Mediator
{
    public void SendMessage(string message, Colleague colleague)
    {
        Console.WriteLine($"{colleague.Name} отримав повідомлення: {message}");
    }
}

//Клас-учасник, який взаємодіє через посередника
class Colleague
{
    public string Name { get; }
    private Mediator _mediator; //Посередник

    public Colleague(string name, Mediator mediator)
    {
        Name = name;
        _mediator = mediator;
    }

    public void Send(string message) => _mediator.SendMessage(message, this);
}

class Program
{
    static void Main()
    {
        Mediator mediator = new Mediator();
        Colleague user1 = new Colleague("User1", mediator);
        Colleague user2 = new Colleague("User2", mediator);

        user1.Send("Привіт!"); 
        user2.Send("Привіт, User1!");
    }
}
