//Замість викидання виключення, метод повертає спеціальне значення Double.NaN, якщо температура нижча за абсолютний нуль, та клієнтський код перевіряє це

public class TemperatureConverter {
    public static double convertToCelsius(double fahrenheit) {
        if (fahrenheit < -459.67) {
            // Повертаємо NaN, щоб позначити недопустиме значення
            return Double.NaN;
        }
        return (fahrenheit - 32) * 5 / 9;
    }

    public static void main(String[] args) {    
        double celsius = convertToCelsius(-500);
        if (Double.isNaN(celsius)) {
            System.out.println("Помилка: Неприпустима температура: менше абсолютного нуля");
        } else {
            System.out.println("Температура в градусах Цельсія: " + celsius);
        }
    }
}
