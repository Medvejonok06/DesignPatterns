//Перемістив цей метод з суперкласу у відповідні підкласи

class Animal {
  //Метод makeSound більше не потрібен у всіх підкласах, тому його видаляємо звідси
}

class Dog extends Animal {
  //Метод makeSound тут не використовується, тому не додаємо його
}

class Cat extends Animal {
  void makeSound() {
    System.out.println("Meow");
  }
}
