﻿//Визначає сімейство схожих алгоритмів і розміщує кожен з них у власному класі
using System;

interface IStrategy
{
    void Execute();
}

class ConcreteStrategyA : IStrategy
{
    public void Execute() => Console.WriteLine("Виконання стратегії A");
}

class ConcreteStrategyB : IStrategy
{
    public void Execute() => Console.WriteLine("Виконання стратегії B");
}

//Контекст, що використовує стратегію
class Context
{
    private IStrategy _strategy;

    public void SetStrategy(IStrategy strategy) => _strategy = strategy;

    public void ExecuteStrategy() => _strategy.Execute();
}

class Program
{
    static void Main()
    {
        Context context = new Context();

        context.SetStrategy(new ConcreteStrategyA());
        context.ExecuteStrategy();

        context.SetStrategy(new ConcreteStrategyB());
        context.ExecuteStrategy();
    }
}
