﻿using System;
using System.Collections.Generic;

// Інтерфейс для підписників
interface IObserver
{
    void Update(string message); // Метод, який буде викликаний при оновленні
}

// Клас, що є спостережуваним
class Subject
{
    private List<IObserver> _observers = new List<IObserver>(); // Список підписників

    public void Attach(IObserver observer) => _observers.Add(observer); // Додає підписника

    public void Detach(IObserver observer) => _observers.Remove(observer); // Видаляє підписника

    public void Notify(string message) // Повідомляє всіх підписників
    {
        foreach (var observer in _observers)
            observer.Update(message);
    }
}

// Конкретний підписник
class ConcreteObserver : IObserver
{
    private string _name;

    public ConcreteObserver(string name) => _name = name;

    public void Update(string message) => Console.WriteLine($"{_name} отримав повідомлення: {message}");
}

// Тестування
class Program
{
    static void Main()
    {
        Subject subject = new Subject();

        ConcreteObserver observer1 = new ConcreteObserver("Спостерігач 1");
        ConcreteObserver observer2 = new ConcreteObserver("Спостерігач 2");

        subject.Attach(observer1);
        subject.Attach(observer2);

        subject.Notify("Дані оновлено!"); // Сповіщає всіх підписників
    }
}
