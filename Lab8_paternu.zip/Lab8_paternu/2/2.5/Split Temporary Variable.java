//Кожна змінна відповідає лише за одну конкретну величину

public class LoanCalculator {

    public double calculateLoanInterest(double loanAmount, double annualInterestRate, int loanTermYears) {
        double interestRate = annualInterestRate / 100;

        //Окремо обчислюємо щомісячну процентну ставку
        double monthlyInterestRate = interestRate / 12;

        //Окремо обчислюємо загальну кількість платежів
        int numberOfPayments = loanTermYears * 12;

        double totalInterest = 0;

        for (int i = 0; i < numberOfPayments; i++) {
            totalInterest += loanAmount * monthlyInterestRate;
        }

        return totalInterest;
    }

    // Інші методи класу...
}
