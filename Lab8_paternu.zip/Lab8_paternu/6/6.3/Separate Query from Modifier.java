// Розділив метод на два – один повертає баланс без змін (query), а інший виконує модифікацію стану (modifier), віднімаючи комісію

public class Account {
    private double balance;

    public Account(double initialBalance) {
        this.balance = initialBalance;
    }

    //Метод повертає баланс без зміни стану об'єкта
    public double getBalance() {
        return balance;
    }

    //Метод знімає комісію з балансу, змінюючи стан об'єкта
    public void deductCommission() {
        double commissionRate = 0.05;
        balance -= balance * commissionRate;
    }

    public static void main(String[] args) {
        Account account = new Account(1000);
        
        System.out.println("Баланс до зняття комісії: " + account.getBalance());
        account.deductCommission();
        System.out.println("Баланс після зняття комісії: " + account.getBalance());
    }
}
