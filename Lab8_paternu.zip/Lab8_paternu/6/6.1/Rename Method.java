//Перейменував метод у більш зрозумілу і конкретну назву

public class Calculator {

    public int add(int x, int y) {
        return x + y;
    }

    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        int result = calculator.add(5, 7);
        System.out.println("Результат додавання: " + result);
    }
}
