﻿using System;
using System.Collections.Generic;

// Інтерфейс виразу, який всі інші вирази будуть реалізовувати
interface IExpression
{
    int Interpret(Dictionary<string, int> context); // Метод для обчислення значення виразу
}

// Конкретний вираз - просто число
class NumberExpression : IExpression
{
    private int _number; // Число, яке зберігається у виразі

    public NumberExpression(int number) => _number = number; // Конструктор для ініціалізації числа

    public int Interpret(Dictionary<string, int> context) => _number; // Повертає число
}

// Конкретний вираз - змінна
class VariableExpression : IExpression
{
    private string _name; // Назва змінної

    public VariableExpression(string name) => _name = name; // Конструктор

    public int Interpret(Dictionary<string, int> context) => context[_name]; // Повертає значення змінної з контексту
}

// Тестування патерну
class Program
{
    static void Main()
    {
        var context = new Dictionary<string, int> { { "x", 10 }, { "y", 20 } }; // Контекст змінних

        IExpression expr = new VariableExpression("x"); // Створюємо вираз змінної "x"

        Console.WriteLine($"Результат: {expr.Interpret(context)}"); // Виведе 10
    }
}
