//Розділили метод calculateSalary на 3 окремих допоміжних методи: calculateBaseSalaryWithOvertime(), calculateBonus(), calculateNetSalary()


public class SalaryCalculator {

    public double calculateSalary(Employee employee) {
        double baseWithOvertime = calculateBaseSalaryWithOvertime(employee); //базова + понаднормова
        double bonus = calculateBonus(employee); //бонус
        double totalSalary = baseWithOvertime + bonus; //загальна зарплата до податків
        return calculateNetSalary(totalSalary, employee.getTaxRate()); //чиста зарплата після податків
    }

    //Обчислює базову зарплату з урахуванням понаднормових годин, якщо понаднормових немає – повертає тільки базову зарплату
    private double calculateBaseSalaryWithOvertime(Employee employee) {
        double baseSalary = employee.getBaseSalary();
        int overtimeHours = employee.getOvertimeHours();

        if (overtimeHours > 0) {
            double overtimePay = overtimeHours * baseSalary * 1.5;
            return baseSalary + overtimePay;
        }

        return baseSalary;
    }

    //Обчислює бонус як відсоток від базової зарплати
    private double calculateBonus(Employee employee) {
        return employee.getBaseSalary() * employee.getBonusPercentage() / 100;
    }

    // Обчислює чисту зарплату після вирахування податку
    private double calculateNetSalary(double totalSalary, double taxRate) {
        double taxAmount = totalSalary * taxRate / 100;
        return totalSalary - taxAmount;
    }

    // Інші методи класу...
}
