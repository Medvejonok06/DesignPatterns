//Створив ієрархію класів з базовим класом Shape та реалізував метод calculateArea() в кожному підкласі

// Базовий клас
abstract class Shape {
    public abstract double calculateArea();
}

//Підклас: Коло
class Circle extends Shape {
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    @Override
    public double calculateArea() {
        return Math.PI * radius * radius;
    }
}

//Підклас: Прямокутник
class Rectangle extends Shape {
    private double length;
    private double width;

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public double getWidth() {
        return width;
    }

    @Override
    public double calculateArea() {
        return length * width;
    }
}

//Клас, що використовує поліморфізм
public class AreaCalculator {
    public double calculateArea(Shape shape) {
        return shape.calculateArea(); //Більше ніяких умовних операторів
    }

    //Тестування
    public static void main(String[] args) {
        AreaCalculator calculator = new AreaCalculator();

        Shape circle = new Circle(5);
        Shape rectangle = new Rectangle(4, 6);

        System.out.println("Circle area: " + calculator.calculateArea(circle));
        System.out.println("Rectangle area: " + calculator.calculateArea(rectangle));
    }
}
