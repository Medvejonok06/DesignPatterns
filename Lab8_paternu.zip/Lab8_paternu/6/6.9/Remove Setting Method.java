//Значення поля встановлюється лише в конструкторі, методів для зміни цього поля більше немає

public class Person {
    private final String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    //Немає сеттера для name — поле незмінне після створення

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    // Інші методи класу
}
