//Використав фабричний метод, який створює об'єкт і виконує додаткові дії (наприклад, реєстрацію)

public class Car {
    private String brand;
    private String model;
    private int year;
    private String color;

    private Car(String brand, String model, int year, String color) {
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.color = color;
    }

    private void registerCar() {
        System.out.println("Car registered successfully!");
    }

    /**
     * Фабричний метод для створення та реєстрації автомобіля.
     * @param brand
     * @param model
     * @param year
     * @param color
     * @return
     */
    public static Car createAndRegisterCar(String brand, String model, int year, String color) {
        Car car = new Car(brand, model, year, color);
        car.registerCar();
        return car;
    }

    // Інші методи класу
}
