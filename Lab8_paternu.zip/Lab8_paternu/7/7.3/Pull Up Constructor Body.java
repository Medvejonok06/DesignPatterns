//Створив конструктор у суперкласі, виніс туди спільний код і викликав його з конструкторів підкласів

class Animal {
  protected String name;
  protected int age;

  public Animal(String name, int age) {
    this.name = name;
    this.age = age;
  }
}

class Dog extends Animal {
  private String breed;

  public Dog(String name, int age, String breed) {
    super(name, age);  //Виклик конструктора суперкласу
    this.breed = breed;
  }
}

class Cat extends Animal {
  private String color;

  public Cat(String name, int age, String color) {
    super(name, age);  //Виклик конструктора суперкласу
    this.color = color;
  }
}
