//Виніс дані замовлення в окремий клас Order, а OrderManager тепер управляє замовленнями через цей клас

public class Main {
    public static void main(String[] args) {
        //Об’єкт замовлення
        Order order = new Order("Ivan Ivanov", "Smartphone", 2);

        //Менеджер замовлень і додаємо замовлення
        OrderManager orderManager = new OrderManager();
        orderManager.setOrder(order);

        System.out.println("Customer: " + orderManager.getOrder().getCustomerName());
        System.out.println("Product: " + orderManager.getOrder().getProductName());
        System.out.println("Quantity: " + orderManager.getOrder().getQuantity());

        orderManager.getOrder().setQuantity(3);
        System.out.println("Updated quantity: " + orderManager.getOrder().getQuantity());
    }
}

//Клас даних предметної області, містить інформацію про замовлення
class Order {
    private String customerName;
    private String productName;
    private int quantity;

    public Order(String customerName, String productName, int quantity) {
        this.customerName = customerName;
        this.productName = productName;
        this.quantity = quantity;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}

//Клас управління замовленнями, який тепер працює з об’єктом Order, а не зберігає дані безпосередньо
class OrderManager {
    private Order order;

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    // Інші методи управління замовленнями
}
