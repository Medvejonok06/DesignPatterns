//Додав у Course поле для зберігання списку студентів, і під час запису студента на курс оновлюємо обидва класи

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Student student1 = new Student("Andrii");
        Student student2 = new Student("Oksana");

        Course course = new Course("Mathematics");

        student1.enrollCourse(course);
        student2.enrollCourse(course);

        System.out.println("Students enrolled in " + course.getTitle() + ":");
        for (Student s : course.getStudents()) {
            System.out.println("- " + s.getName());
        }

        System.out.println(student1.getName() + " enrolled in:");
        for (Course c : student1.getCourses()) {
            System.out.println("- " + c.getTitle());
        }
    }
}

class Student {
    private String name;
    private List<Course> courses;

    public Student(String name) {
        this.name = name;
        this.courses = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public List<Course> getCourses() {
        return courses;
    }

    //Метод запису на курс з оновленням обох сторін зв’язку
    public void enrollCourse(Course course) {
        if (!courses.contains(course)) {
            courses.add(course);
            course.addStudent(this); //Оновлюємо двосторонній зв'язок
        }
    }
}

class Course {
    private String title;
    private List<Student> students;

    public Course(String title) {
        this.title = title;
        this.students = new ArrayList<>();
    }

    public String getTitle() {
        return title;
    }

    public List<Student> getStudents() {
        return students;
    }

    //Додаємо студента у курс, якщо його там ще немає
    public void addStudent(Student student) {
        if (!students.contains(student)) {
            students.add(student);
            student.enrollCourse(this); //Забезпечуємо двонаправленість
        }
    }
}
