//Розбив складний умовний оператор на окремі методи: isAccessAllowed(): перевірка умов доступу, grantAccess(): дії при дозволі, denyAccess(): дії при забороні

public class AccessManager {

    public void checkAccess(User user, Resource resource) {
        if (isAccessAllowed(user, resource)) {
            grantAccess(); //Дозволяємо доступ
        } else {
            denyAccess(); //Забороняємо доступ
        }
    }

    private boolean isAccessAllowed(User user, Resource resource) {
        return user != null && user.isLoggedIn() &&
               resource != null && user.hasPermission(resource);
    }

    //Приватний метод, що виконується у разі дозволу доступу
    private void grantAccess() {
        System.out.println("Access granted");
    }

    //Приватний метод, що виконується у разі заборони доступу
    private void denyAccess() {
        System.out.println("Access denied");
    }
}