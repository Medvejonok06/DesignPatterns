//Додав параметр taxRate, щоб врахувати податок у обчисленні загальної суми

public class OrderCalculator {

    public double calculateTotal(double price, int quantity, double taxRate) {
        double subtotal = price * quantity;
        double taxAmount = subtotal * taxRate;
        return subtotal + taxAmount;
    }

    public static void main(String[] args) {
        OrderCalculator calculator = new OrderCalculator();
        double total = calculator.calculateTotal(100.0, 3, 0.1);
        System.out.println("Загальна сума з податком: " + total);
    }
}
