//Виділив окремі класи: PersonInfo, Relationships, TaskManager
//Об'єднав ці класи у вищий клас 
    
public class PersonInfo {
    private String name;
    private int age;
    private String gender;

    public PersonInfo(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    // Геттери
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
}

public class Relationships {
    private List<String> friends = new ArrayList<>();
    private List<String> enemies = new ArrayList<>();

    public void addFriend(String friend) {
        friends.add(friend);
    }
    public void removeFriend(String friend) {
        friends.remove(friend);
    }
    public void addEnemy(String enemy) {
        enemies.add(enemy);
    }
    public void removeEnemy(String enemy) {
        enemies.remove(enemy);
    }

    public List<String> getFriends() {
        return friends;
    }
    public List<String> getEnemies() {
        return enemies;
    }
}

public class TaskManager {
    private List<String> tasks = new ArrayList<>();

    public void addTask(String task) {
        tasks.add(task);
    }
    public void removeTask(String task) {
        tasks.remove(task);
    }

    public List<String> getTasks() {
        return tasks;
    }
}

// Вищий клас, що агрегує компоненти
public class Person {
    private PersonInfo info;
    private Relationships relationships;
    private TaskManager taskManager;

    public Person(String name, int age, String gender) {
        this.info = new PersonInfo(name, age, gender);
        this.relationships = new Relationships();
        this.taskManager = new TaskManager();
    }

    public PersonInfo getInfo() { return info; }
    public Relationships getRelationships() { return relationships; }
    public TaskManager getTaskManager() { return taskManager; }

    public void displayInfo() {
        System.out.println("Name: " + info.getName());
        System.out.println("Age: " + info.getAge());
        System.out.println("Gender: " + info.getGender());
        System.out.println("Friends: " + relationships.getFriends());
        System.out.println("Enemies: " + relationships.getEnemies());
        System.out.println("Tasks: " + taskManager.getTasks());
    }
}
