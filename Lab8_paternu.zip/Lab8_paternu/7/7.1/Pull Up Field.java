//Перемістив поле в суперклас, прибравши його з підкласів

class Vehicle {
    protected String color;

    public Vehicle(String color) {
        this.color = color;
    }
}


//Клас Car — підклас Vehicle з додатковим полем model
class Car extends Vehicle {
    private String model;

    public Car(String color, String model) {
        super(color);
        this.model = model;
    }
}

//Клас Truck — підклас Vehicle з полями model та loadCapacity
class Truck extends Vehicle {
    private String model;
    private int loadCapacity;

    public Truck(String color, int loadCapacity, String model) {
        super(color);
        this.model = model;
        this.loadCapacity = loadCapacity;
    }
}
