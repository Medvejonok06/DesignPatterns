//Об'єднав ці методи в один, який приймає параметр степеня

public class Calculator {

    //Метод для піднесення числа num до степеня power
    public int calculatePower(int num, int power) {
        int result = 1;
        for (int i = 0; i < power; i++) {
            result *= num;
        }
        return result;
    }

    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        
        System.out.println("Квадрат 3: " + calculator.calculatePower(3, 2));
        System.out.println("Куб 3: " + calculator.calculatePower(3, 3));
    }
}
