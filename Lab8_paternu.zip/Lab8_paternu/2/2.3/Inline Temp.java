//Вилучив змінну tempInCelsius, а сам вираз вставив прямо в return

public class TemperatureConverter {
    public double convertToCelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
    }
    // Інші методи класу...
}
