//Замість створення багатьох однакових об’єктів Currency для кожного Product, створив фабрику CurrencyFactory, яка повертає один спільний екземпляр Currency для кожного унікального коду валюти

import java.util.HashMap;
import java.util.Map;

public class Main {

    public static void main(String[] args) {
        Product product1 = new Product("Phone", 699.99, "USD");
        Product product2 = new Product("Laptop", 1299.99, "USD");
        Product product3 = new Product("Coffee", 3.99, "EUR");

        System.out.println(product1.getName() + " costs " + product1.getPrice() + " " + product1.getCurrencyCode());
        System.out.println(product2.getName() + " costs " + product2.getPrice() + " " + product2.getCurrencyCode());
        System.out.println(product3.getName() + " costs " + product3.getPrice() + " " + product3.getCurrencyCode());

        //Перевірка, що однакові валюти — це один об'єкт
        System.out.println("product1 and product2 use same Currency object: " + 
            (product1.getCurrency() == product2.getCurrency()));  //true
        System.out.println("product1 and product3 use same Currency object: " + 
            (product1.getCurrency() == product3.getCurrency()));  //false
    }
}

class Currency {
    private String code;

    public Currency(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}

class CurrencyFactory {

    //Статичне поле — мапа, що зберігає вже створені об’єкти Currency за кодом валюти
    private static Map<String, Currency> currencies = new HashMap<>();

    //Статичний метод, який повертає об’єкт Currency за переданим кодом
    public static Currency getCurrency(String code) {
        //Якщо мапа ще не містить об’єкта з таким кодом
        if (!currencies.containsKey(code)) {
            //Створюємо новий об’єкт Currency і додаємо його в мапу
            currencies.put(code, new Currency(code));
        }
        return currencies.get(code);
    }
}


class Product {
    private String name;
    private double price;
    private Currency currency;

    public Product(String name, double price, String currencyCode) {
        this.name = name;
        this.price = price;
        this.currency = CurrencyFactory.getCurrency(currencyCode);
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getCurrencyCode() {
        return currency.getCode();
    }

    public Currency getCurrency() {
        return currency;
    }
}
