﻿//Дає змогу об’єктам змінювати поведінку в залежності від їхнього стану
using System;

interface IState
{
    void Handle(Context context);
}

//Конкретний стан A
class StateA : IState
{
    //Змінює стан об'єкта context на StateB
    public void Handle(Context context)
    {
        Console.WriteLine("Перехід у стан B");
        context.SetState(new StateB());
    }
}

//Конкретний стан B
class StateB : IState
{
    public void Handle(Context context)
    {
        Console.WriteLine("Перехід у стан A");
        context.SetState(new StateA());
    }
}

//Контекст, що управляє станами
class Context
{
    private IState _state;

    public Context(IState state) => _state = state;

    public void SetState(IState state) => _state = state;

    public void Request() => _state.Handle(this);
}
class Program
{
    static void Main()
    {
        Context context = new Context(new StateA());
        // Перехід до станів А/В
        context.Request(); 
        context.Request();
    }
}
